a:4:{i:1;a:7:{s:12:"module_title";a:2:{i:1;s:11:"Mauris quam";i:3;s:0:"";}s:11:"description";a:2:{i:1;s:1026:"&lt;div class=&quot;media mauris_quam&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/img_cus.jpg&quot; /&gt;&lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h1&gt;Mauris&lt;span&gt; quam&lt;/span&gt;&lt;/h1&gt;

&lt;div class=&quot;content&quot;&gt;
&lt;p class=&quot;media-text&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eu ligula velit. Proin molestie, nisi at mollis adipiscing, lorem justo facilisis est, quis lobortis metus ante id turpis. Aliquam volutpat tortor nec sem interdum cursus. Donec eu lectus vel augue consequat ultricies at ut tellus. Aliquam erat volutpat Nunc nec enim sit amet magna volutpat eleifend. Morbi orci lacus, viverra non viverra sed, sagittis eget vitae sem adipiscing vestibulum. Etiam mattis luctus dapibus&lt;/p&gt;

&lt;p class=&quot;pull-right&quot;&gt;&lt;a class=&quot;bnt&quot; href=&quot;#&quot;&gt;Shop now&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:0:"";}s:9:"layout_id";s:1:"1";s:8:"position";s:9:"promotion";s:6:"status";s:1:"1";s:12:"module_class";s:13:" hidden-phone";s:10:"sort_order";s:1:"1";}i:2;a:7:{s:12:"module_title";a:2:{i:1;s:26:"sign up for our newsletter";i:3;s:0:"";}s:11:"description";a:2:{i:1;s:778:"&lt;div class=&quot;newsletter-service&quot;&gt;
&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span6 newsletter&quot;&gt;
&lt;h2&gt;sign up for our newsletter&lt;/h2&gt;

&lt;div class=&quot;newsletter-submit&quot;&gt;&lt;input alt=&quot;username&quot; class=&quot;inputbox&quot; name=&quot;email&quot; size=&quot;31&quot; type=&quot;text&quot; value=&quot;Type your email&quot; /&gt;&lt;input class=&quot;button&quot; name=&quot;Submit&quot; type=&quot;submit&quot; value=&quot;Sign up&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span6 service&quot;&gt;
&lt;h2&gt;24/7 Customer Service&lt;/h2&gt;

&lt;p&gt;Nulla rhoncus blandit lacus in scelerisque leo donec urna lobor tis molestie.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:0:"";}s:9:"layout_id";s:1:"1";s:8:"position";s:11:"content_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:3;a:7:{s:12:"module_title";a:2:{i:1;s:18:"Menu in Footer Top";i:3;s:0:"";}s:11:"description";a:2:{i:1;s:540:"&lt;div class=&quot;listmenu navbar&quot;&gt;
&lt;ul class=&quot;nav&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Fusce hen&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Proin imper&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Sed non sem &lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Nunc vel&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Curabitur &lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Fermentum &lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:0:"";}s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:4;a:7:{s:12:"module_title";a:2:{i:1;s:12:"Follow us on";i:3;s:0:"";}s:11:"description";a:2:{i:1;s:450:"&lt;div class=&quot;social&quot;&gt;
&lt;h4 class=&quot;pull-left&quot;&gt;Follow us on&lt;/h4&gt;

&lt;div class=&quot;custom_follow&quot;&gt;&lt;a class=&quot;facebook&quot; href=&quot;#&quot;&gt;facebook&lt;/a&gt; &lt;a class=&quot;twitter&quot; href=&quot;#&quot;&gt;twitter&lt;/a&gt; &lt;a class=&quot;mail&quot; href=&quot;#&quot;&gt;Mails&lt;/a&gt; &lt;a class=&quot;rss&quot; href=&quot;#&quot;&gt;rss&lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
";i:3;s:0:"";}s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";i:2;}}