<?php 

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Save: %s';
$_['text_contact_us'] = 'Contact Us';
?>